# coding: utf-8 

# Run "python report.py" to generate the mxos test result summay

file_in=open('summary.log','rb')

feature_list=[
"Domain",
"Mailbox",
"Cos",
"Folder",
"Message",
"Notify",
"Address Book",
"Tasks",
]

